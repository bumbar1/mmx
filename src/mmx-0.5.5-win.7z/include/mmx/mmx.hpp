#ifndef MMX_MMX_HPP
#define MMX_MMX_HPP 1

/**
 * One header to include them all
 */

#include "config.hpp"
#include "date.hpp"
#include "dir.hpp"
#include "logger.hpp"
#include "math.hpp"
#include "sqlite.hpp"
#include "time.hpp"
#include "timer.hpp"
#include "util.hpp"
#include "vector2.hpp"
#include "vector3.hpp"

#endif      // MMX_MMX_HPP
